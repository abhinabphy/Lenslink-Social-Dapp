# Decentralized Social Media Application

This is the complete, finished application for the Decentralized Social Media Application.

Video: https://www.youtube.com/watch?v=FiZIGm41dgE

For all related questions and discussions about this project, check out the discord:
https://discord.gg/2FfPeEk2mX
